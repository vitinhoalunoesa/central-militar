(function(){
 const KEY='centralMilitarProgressV2';
 const blank={correct:0,wrong:0,lessons:[],attempts:0,lastStudy:null};
 function get(){try{return Object.assign({},blank,JSON.parse(localStorage.getItem(KEY)||'{}'))}catch(e){return {...blank}}}
 function save(d){localStorage.setItem(KEY,JSON.stringify(d));}
 function lessonCount(){return document.querySelectorAll('[data-lesson]').length||4}
 function render(){const d=get(),done=d.lessons.length,total=4,percent=Math.min(100,Math.round(done/total*100));
  set('stat-questions',d.correct);set('stat-lessons',done);set('stat-progress',percent+'%');set('mission-progress',null);const mp=document.getElementById('mission-progress');if(mp)mp.style.width=percent+'%';set('mission-label',done+' de '+total+' tópicos');
  set('progress-correct',d.correct);set('progress-wrong',d.wrong);set('progress-lessons',done);set('progress-percent',percent+'%');
  document.querySelectorAll('[data-lesson]').forEach(b=>{const done=d.lessons.includes(b.dataset.lesson);b.textContent=done?'✓ Aula concluída':'Marcar como concluída';b.classList.toggle('btn-primary',done);b.classList.toggle('btn-outline',!done)});
 }
 function set(id,val){const e=document.getElementById(id);if(e&&val!==null)e.textContent=val}
 document.addEventListener('click',e=>{const b=e.target.closest('[data-lesson]');if(!b)return;const d=get(),id=b.dataset.lesson;d.lessons=d.lessons.includes(id)?d.lessons.filter(x=>x!==id):[...d.lessons,id];d.lastStudy=new Date().toISOString();save(d);render()});
 const ex=document.getElementById('export-data');if(ex)ex.addEventListener('click',()=>{const blob=new Blob([JSON.stringify(get(),null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='central-militar-progresso.json';a.click();URL.revokeObjectURL(url)});
 const reset=document.getElementById('reset-data');if(reset)reset.addEventListener('click',()=>{if(confirm('Tem certeza que deseja apagar todo o progresso salvo neste navegador?')){localStorage.removeItem(KEY);render()}});
 window.CentralMilitar={get,save,render};document.addEventListener('DOMContentLoaded',render);render();
})();
