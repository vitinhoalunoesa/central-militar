(function(){const form=document.getElementById('quiz-form');if(!form)return;const answers=['b','a','b','b','c'];const explanations=[
'47 + 28 = 47 + 20 + 8 = 67 + 8 = 75.',
'83 − 46: emprestamos uma dezena. 13 − 6 = 7 e 7 − 4 = 3. Resultado: 37.',
'7 × 8 = 56. Multiplicar é somar o mesmo número repetidamente.',
'84 ÷ 7 = 12, porque 7 × 12 = 84.',
'1/2 equivale a 2/4. Então 2/4 + 1/4 = 3/4.'
];form.addEventListener('submit',e=>{e.preventDefault();let correct=0,answered=0;answers.forEach((a,i)=>{const picked=form.querySelector('input[name="q'+i+'"]:checked'),box=document.getElementById('exp'+i);if(picked)answered++;const ok=!!picked&&picked.value===a;if(ok)correct++;box.className='explanation '+(ok?'correct':'wrong');box.textContent=(ok?'Correto! ':'Resposta correta: '+a.toUpperCase()+'. ')+explanations[i]});const result=document.getElementById('quiz-result');result.textContent=`Resultado: ${correct}/5 acertos · ${answered}/5 respondidas.`;const d=window.CentralMilitar.get();d.correct+=correct;d.wrong+=(answered-correct);d.attempts++;d.lastStudy=new Date().toISOString();window.CentralMilitar.save(d);window.CentralMilitar.render();result.scrollIntoView({behavior:'smooth',block:'nearest'});});})();
